#!/usr/bin/env python3
"""Final-result wrapper: no PASS is emitted before full local cleanup is proven."""
from __future__ import annotations

import argparse
import errno
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

LAUNCHER_DEADLINE_SECONDS = 50
TERM_GRACE_SECONDS = 2


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def group_absent(pgid: int) -> bool:
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return True
    except OSError as exc:
        return exc.errno == errno.ESRCH
    return False


def stop_group(process: subprocess.Popen[bytes]) -> str:
    if process.poll() is not None:
        return "NOT_NEEDED"
    os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=TERM_GRACE_SECONDS)
        return "TERM"
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=TERM_GRACE_SECONDS)
        return "KILL"


def emit(result: dict[str, Any]) -> int:
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0 if result["result"] == "PASS_CHANNEL" else 2


def valid_tmp_root(root: Path) -> bool:
    return root.parent == Path("/tmp") and root.name.startswith("patroai-stg008-channel-diag-") and not root.is_symlink()


def within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
    except ValueError:
        return False
    return True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--railway-bin", required=True)
    parser.add_argument("--temporary-root", required=True)
    parser.add_argument("--launcher-source", required=True)
    args = parser.parse_args()
    root = Path(args.temporary_root).resolve()
    launcher_source = Path(args.launcher_source).resolve()
    supplied_cli = Path(args.railway_bin).resolve()
    result: dict[str, Any] = {
        "gate": "STAGING_008_CHANNEL_DIAGNOSTIC_GO",
        "timestamp_utc": utc_now(),
        "wrapper_deadline_seconds": LAUNCHER_DEADLINE_SECONDS,
        "launcher": None,
        "parent_reaped": False,
        "process_group_absent": False,
        "temporary_home_absent": False,
        "temporary_cli_absent": False,
        "raw_buffers_absent": False,
        "launcher_temp_absent": False,
        "cleanup_confirmed": False,
        "result": "INCONCLUSIVE",
        "reason": "UNSET",
    }
    if not valid_tmp_root(root) or not root.is_dir():
        result["reason"] = "TEMPORARY_ROOT_INVALID"
        return emit(result)
    if not launcher_source.is_file():
        result["reason"] = "LAUNCHER_SOURCE_UNAVAILABLE"
        return emit(result)
    cli_root = root / "cli"
    if not supplied_cli.is_file() or not os.access(supplied_cli, os.X_OK) or not within(supplied_cli, cli_root):
        result["reason"] = "TEMPORARY_CLI_INVALID"
        return emit(result)
    staged_launcher = root / "launcher.py"
    temporary_home = root / "home"
    process: subprocess.Popen[bytes] | None = None
    try:
        shutil.copy2(launcher_source, staged_launcher)
        temporary_home.mkdir(mode=0o700)
        process = subprocess.Popen(
            [sys.executable, str(staged_launcher), "--railway-bin", str(supplied_cli), "--temporary-home", str(temporary_home)],
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True,
        )
        try:
            stdout, stderr = process.communicate(timeout=LAUNCHER_DEADLINE_SECONDS)
            termination = "NOT_NEEDED"
            timed_out = False
        except subprocess.TimeoutExpired:
            timed_out = True
            termination = stop_group(process)
            stdout, stderr = process.communicate()
        result["parent_reaped"] = process.poll() is not None
        result["process_group_absent"] = group_absent(process.pid)
        result["launcher"] = {
            "process_pid": process.pid,
            "process_group_id": process.pid,
            "exit_code": process.returncode,
            "timeout": timed_out,
            "termination": termination,
            "stdout_bytes": len(stdout),
            "stderr_bytes": len(stderr),
            "stdout_sha256": digest(stdout),
            "stderr_sha256": digest(stderr),
        }
        if timed_out or not result["parent_reaped"] or not result["process_group_absent"]:
            result["reason"] = "LAUNCHER_TIMEOUT_OR_PROCESS_GROUP_RESIDUAL"
        elif stderr:
            result["reason"] = "LAUNCHER_STDERR_UNCLASSIFIED"
        else:
            try:
                pre = json.loads(stdout.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                result["reason"] = "LAUNCHER_INVALID_JSON"
            else:
                result["pre_cleanup_result"] = pre.get("pre_cleanup_result")
                result["pre_cleanup_reason"] = pre.get("reason")
                if pre.get("pre_cleanup_result") == "CHANNEL_DIAGNOSTIC_OK":
                    result["reason"] = "PRE_CLEANUP_DIAGNOSTIC_OK"
                else:
                    result["reason"] = "PRE_CLEANUP_NOT_OK"
    except Exception as exc:
        result["reason"] = f"WRAPPER_{type(exc).__name__}"
    finally:
        try:
            if root.exists() and not root.is_symlink():
                shutil.rmtree(root)
        except Exception:
            result["reason"] = "CLEANUP_DELETE_FAILED"
        result["temporary_home_absent"] = not temporary_home.exists()
        result["temporary_cli_absent"] = not cli_root.exists()
        result["raw_buffers_absent"] = not root.exists()
        result["launcher_temp_absent"] = not staged_launcher.exists()
        result["cleanup_confirmed"] = all(
            [result["temporary_home_absent"], result["temporary_cli_absent"], result["raw_buffers_absent"], result["launcher_temp_absent"]]
        )
    if result["reason"] == "PRE_CLEANUP_DIAGNOSTIC_OK" and result["cleanup_confirmed"] and result["parent_reaped"] and result["process_group_absent"]:
        result["result"] = "PASS_CHANNEL"
        result["reason"] = "CHANNEL_DIAGNOSTIC_AND_CLEANUP_CONFIRMED"
    elif not result["cleanup_confirmed"]:
        result["result"] = "INCONCLUSIVE"
        result["reason"] = "CLEANUP_UNCONFIRMED"
    return emit(result)


if __name__ == "__main__":
    sys.exit(main())
