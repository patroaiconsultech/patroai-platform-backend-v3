#!/usr/bin/env python3
"""Pre-cleanup probe used only by the audited STG008 outer wrapper."""
from __future__ import annotations

import argparse
import errno
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

WHOAMI_DEADLINE_SECONDS = 20
GRAPHQL_DEADLINE_SECONDS = 20
TERM_GRACE_SECONDS = 2
DIAGNOSTIC_QUERY = "query { __typename }"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def build_env(home: str) -> dict[str, str]:
    return {"PATH": os.environ.get("PATH", ""), "HOME": home, "RAILWAY_HOME": str(Path(home) / ".railway"), "LC_ALL": "C"}


def process_group_absent(pgid: int) -> bool:
    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return True
    except OSError as exc:
        return exc.errno == errno.ESRCH
    return False


def terminate_pgid(pgid: int) -> str:
    if process_group_absent(pgid):
        return "NOT_NEEDED"
    os.killpg(pgid, signal.SIGTERM)
    deadline = time.monotonic() + TERM_GRACE_SECONDS
    while time.monotonic() < deadline:
        if process_group_absent(pgid):
            return "TERM"
        time.sleep(0.05)
    os.killpg(pgid, signal.SIGKILL)
    deadline = time.monotonic() + TERM_GRACE_SECONDS
    while time.monotonic() < deadline:
        if process_group_absent(pgid):
            return "KILL"
        time.sleep(0.05)
    return "RESIDUAL"


def run_bounded(command: list[str], env: dict[str, str], deadline: int) -> dict[str, Any]:
    start = utc_now()
    process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, start_new_session=True)
    timeout = False
    termination = "NOT_NEEDED"
    try:
        stdout, stderr = process.communicate(timeout=deadline)
    except subprocess.TimeoutExpired:
        timeout = True
        termination = terminate_pgid(process.pid)
        stdout, stderr = process.communicate()
    residual_cleanup = "NOT_NEEDED"
    if not process_group_absent(process.pid):
        residual_cleanup = terminate_pgid(process.pid)
    end = utc_now()
    return {
        "cli_start": start,
        "process_pid": process.pid,
        "process_group_id": process.pid,
        "start_timestamp": start,
        "end_timestamp": end,
        "deadline_seconds": deadline,
        "exit_code": process.returncode,
        "timeout": timeout,
        "termination": termination,
        "residual_cleanup": residual_cleanup,
        "parent_reaped": process.poll() is not None,
        "process_group_absent": process_group_absent(process.pid),
        "stdout_bytes": len(stdout),
        "stderr_bytes": len(stderr),
        "stdout_sha256": digest(stdout),
        "stderr_sha256": digest(stderr),
        "_stdout": stdout,
    }


def sanitized(operation: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in operation.items() if not key.startswith("_")}


def stderr_disposition(operation: dict[str, Any]) -> str:
    return "ABSENT" if operation["stderr_bytes"] == 0 else "PRESENT_UNCLASSIFIED_REDACTED"


def emit_preliminary(result: dict[str, Any]) -> int:
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    # The probe can never assert final success; only its wrapper may do that after cleanup.
    return 2


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--railway-bin", required=True)
    parser.add_argument("--temporary-home", required=True)
    args = parser.parse_args()
    railway_bin = Path(args.railway_bin).resolve()
    temporary_home = Path(args.temporary_home).resolve()
    result: dict[str, Any] = {
        "gate": "STAGING_008_CHANNEL_DIAGNOSTIC_GO",
        "timestamp_utc": utc_now(),
        "query_literal_sha256": digest(DIAGNOSTIC_QUERY.encode()),
        "query_literal_verified": True,
        "whoami": None,
        "graphql_query": None,
        "whoami_stderr_disposition": None,
        "graphql_stderr_disposition": None,
        "pre_cleanup_result": "INCONCLUSIVE",
        "result": "PRE_CLEANUP_ONLY",
        "cleanup_required": True,
        "reason": "UNSET",
    }
    if not railway_bin.is_file() or not os.access(railway_bin, os.X_OK):
        result["reason"] = "RAILWAY_BINARY_UNAVAILABLE"
        return emit_preliminary(result)
    if not str(temporary_home).startswith("/tmp/"):
        result["reason"] = "TEMPORARY_HOME_OUTSIDE_TMP"
        return emit_preliminary(result)
    env = build_env(str(temporary_home))
    try:
        whoami = run_bounded([str(railway_bin), "whoami"], env, WHOAMI_DEADLINE_SECONDS)
        result["whoami"] = sanitized(whoami)
        result["whoami_stderr_disposition"] = stderr_disposition(whoami)
        if whoami["timeout"] or not whoami["parent_reaped"] or not whoami["process_group_absent"]:
            result["reason"] = "WHOAMI_TIMEOUT_OR_PROCESS_GROUP_RESIDUAL"
            return emit_preliminary(result)
        if whoami["exit_code"] != 0 or whoami["stderr_bytes"] != 0:
            result["reason"] = "WHOAMI_NOT_CLEAN"
            return emit_preliminary(result)
        graphql = run_bounded([str(railway_bin), "api", DIAGNOSTIC_QUERY], env, GRAPHQL_DEADLINE_SECONDS)
        result["graphql_query"] = sanitized(graphql)
        result["graphql_stderr_disposition"] = stderr_disposition(graphql)
        if graphql["timeout"] or not graphql["parent_reaped"] or not graphql["process_group_absent"]:
            result["reason"] = "GRAPHQL_TIMEOUT_OR_PROCESS_GROUP_RESIDUAL"
            return emit_preliminary(result)
        if graphql["exit_code"] != 0:
            result["pre_cleanup_result"] = "FAIL_CHANNEL"
            result["reason"] = "GRAPHQL_NONZERO_EXIT"
            return emit_preliminary(result)
        if graphql["stderr_bytes"] != 0:
            result["reason"] = "GRAPHQL_STDERR_UNCLASSIFIED"
            return emit_preliminary(result)
        try:
            response = json.loads(graphql["_stdout"].decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            result["pre_cleanup_result"] = "FAIL_CHANNEL"
            result["reason"] = "GRAPHQL_INVALID_JSON"
            return emit_preliminary(result)
        typename = response.get("data", {}).get("__typename") if isinstance(response, dict) else None
        if not isinstance(typename, str) or not typename:
            result["pre_cleanup_result"] = "FAIL_CHANNEL"
            result["reason"] = "GRAPHQL_UNEXPECTED_RESPONSE"
            return emit_preliminary(result)
        result["pre_cleanup_result"] = "CHANNEL_DIAGNOSTIC_OK"
        result["reason"] = "PRE_CLEANUP_DIAGNOSTIC_OK"
        return emit_preliminary(result)
    except Exception as exc:
        result["reason"] = f"LAUNCHER_{type(exc).__name__}"
        return emit_preliminary(result)


if __name__ == "__main__":
    sys.exit(main())
