# PatroAI V3 — Gate Premium: Diagnóstico de Canal Railway CLI/API

**Decision ID:** `STAGING_008_CHANNEL_DIAGNOSTIC_GO_20260903_001`  
**Correlation ID:** `PATROAI-V3-STG008-CHANNEL-DIAG-20260903-001`  
**Finding fechado no gate:** `STG008-CHANNEL-DIAG-001 / LOW`  
**Estado:** `PREPARED / AWAITING_HUMAN_APPROVAL`

## Objeto e separação de fases

Este gate executa somente a **Fase A — Channel Diagnostic**. Seu propósito é medir a cadeia launcher → CLI Railway → autenticação → API GraphQL → resposta, por meio da única query literal `query { __typename }`. A execução não pode realizar search, describe, query de deployment ou discovery de instância. A Fase B continua bloqueada mesmo se a Fase A retornar `PASS_CHANNEL`.

## Ato único proposto

| Etapa | Limite |
|---|---|
| Instalação / autenticação | CLI somente em `/tmp`; login somente pelo usuário; nenhum token ou valor bruto registrado |
| `whoami` | Exatamente uma execução, deadline independente de 20 s |
| Query GraphQL | Exatamente uma execução literal: `railway api 'query { __typename }'`, deadline independente de 20 s |
| Instrumentação | launcher externo registra PID, start/end, exit/timeout, contagem e SHA-256 dos buffers |
| Timeout | `TERM` ao process group, grace de 2 s, `KILL` somente se necessário, `wait()` e orphan check |
| Stderr | bytes e SHA-256 sempre registrados; conteúdo nunca emitido; stderr não vazio e não classificado gera `INCONCLUSIVE`, não falha automática |
| Processo | `parent_reaped` e `process_group_absent` são comprovados separadamente; `poll()` isolado nunca equivale a ausência de grupo. Se o grupo persistir após o pai encerrar, o launcher aplica `TERM → grace → KILL` ao PGID e só continua se sua ausência for comprovada. |
| Cleanup | wrapper remove home temporário, CLI temporária, launcher encenado, buffers brutos e arquivos de evidência locais, verifica ausência e só então emite resultado final |

## Resultados possíveis

| Resultado | Predicados |
|---|---|
| `PASS_CHANNEL` | `whoami` termina em 20 s; query termina em 20 s; ambos exit 0; stderr vazio; stdout da query é JSON com `data.__typename` string não vazia; pai reaped, process group ausente e cleanup confirmado pelo wrapper |
| `FAIL_CHANNEL` | query termina, mas retorna exit não-zero, JSON inválido ou estrutura de resposta incompatível |
| `INCONCLUSIVE` | timeout, órfão, launcher/CLI indisponível, `whoami` não limpo, stderr não classificável sem expor conteúdo, ou cleanup não comprovado |

## Proibições explícitas

São proibidos: `railway api search`, `describe`, `schema`, query de deployment, segunda query diagnóstica, `--allow-errors`, mutation, subscription, SSH, chave SSH, `railway run`, `railway shell`, ENV, banco, atestador PostgreSQL, Alembic, migration 008, DDL, DML, restart, deploy, GitHub, DNS e produção.

## Texto de autorização humana requerido

> Autorizo exclusivamente o gate `STAGING_008_CHANNEL_DIAGNOSTIC_GO_20260903_001` para instalar a CLI Railway somente se ausente em diretório temporário, autenticar sob meu controle, executar uma única vez `whoami` com deadline de 20 segundos e uma única vez a query literal `query { __typename }` com deadline independente de 20 segundos, por wrapper que capture PID, timestamps, exit code/timeout e somente bytes/SHA-256 de stdout/stderr; em timeout, autorizo exclusivamente `TERM → 2 s → KILL se necessário → wait → prova de parent reaped e de process group ausente`, seguido de remoção e prova de ausência de todos os temporários antes de qualquer `PASS_CHANNEL`. Não autorizo search, describe, schema, query de deployment, segunda query, SSH/chave SSH, shell/run, ENV, banco, atestador, Alembic, migration 008, DDL, DML, restart, deploy, GitHub, DNS ou produção. Em qualquer falha, interrompa e reporte resultado sanitizado sem nova tentativa.

## Referência

[1]: https://docs.railway.com/cli/api "Railway Docs — railway api"
